require("dotenv").config();
const fs = require("fs");
const path = require("path");
const OpenAI = require("openai");

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || ""
});

// ---- YOUR EXACT SYSTEM PROMPT ----
const system_prompt = `
You are "EnhancedTxnBot," an AI assistant that enriches an existing JSON of bank transactions with enterprise-grade categorization metadata.

When I give you a JSON object like this:

{
  "results": [
    {
      "timestamp": "2025-07-29T14:54:12.411Z",
      "description": "Saving",
      "transaction_type": "DEBIT",
      "transaction_category": "OTHER",
      "transaction_classification": [],
      "amount": -50,
      "currency": "GBP",
      "transaction_id": "b2ecebe2fe8d8b380e0f656ce931e3d1",
      "provider_transaction_id": "03be9c5e-1268-426d-ae69-74e698cb762d",
      "normalised_provider_transaction_id": "txn-0b6df3a48b8d1c819",
      "meta": { ... }
    },
    { ... more transactions ... }
  ],
  "status": "Succeeded"
}

You must:

1. For each object in \`results\`, append exactly three new fields:
   - \`generalCategory\` (one of your top-level buckets)
   - \`subCategory\` (a more specific slice under that bucket)
   - \`domainDescription\` (1–2 sentences describing the merchant/domain)

2. Preserve every existing field on each transaction and leave the outer "status" untouched.

3. If you can't confidently pick a subCategory, set:
   - \`generalCategory\`: "General"
   - \`subCategory\`: "General → Miscellaneous"

4. Output the modified JSON object in the same shape, e.g.:

{
  "results": [
    {
      "timestamp": "2025-07-29T14:54:12.411Z",
      "description": "Saving",
      "transaction_type": "DEBIT",
      "transaction_category": "OTHER",
      "transaction_classification": [],
      "amount": -50,
      "currency": "GBP",
      "transaction_id": "b2ecebe2fe8d8b380e0f656ce931e3d1",
      "provider_transaction_id": "03be9c5e-1268-426d-ae69-74e698cb762d",
      "normalised_provider_transaction_id": "txn-0b6df3a48b8d1c819",
      "meta": { ... },
      "generalCategory": "Bank Products",
      "subCategory": "Savings",
      "domainDescription": "This transaction appears to be an internal transfer to a savings account held within the same institution."
    },
    { ... enriched transactions ... }
  ],
  "status": "Succeeded"
}
`;

// ---- EXPRESS HANDLER ----
async function categorizeData(req, res) {
  try {
    const filePath = path.join(__dirname, "../response.json");
    const original = JSON.parse(fs.readFileSync(filePath, "utf8"));

    const transactions = Array.isArray(original.results) ? original.results : [];
    if (transactions.length === 0) {
      return res.status(200).json({
        results: [],
        status: original.status ?? "Succeeded"
      });
    }

    // Process transactions in parallel for faster response
    const enrichedResults = await processTransactionsInParallel(transactions);

    // EXACT output shape you requested:
    return res.status(200).json({
      results: enrichedResults,
      status: original.status ?? "Succeeded"
    });

  } catch (error) {
    console.error("Error in categorizeData:", error);
    return res.status(500).json({
      results: [],
      status: "Failed",
      error: error.message
    });
  }
}

// ---- PARALLEL PROCESSING ----
async function processTransactionsInParallel(transactions) {
  // Process up to 10 transactions in parallel to balance speed and resource usage
  const CONCURRENT_LIMIT = 80;
  const results = [];
  
  for (let i = 0; i < transactions.length; i += CONCURRENT_LIMIT) {
    const batch = transactions.slice(i, i + CONCURRENT_LIMIT);
    const promises = batch.map(transaction => processSingleTransaction(transaction));
    
    try {
      const batchResults = await Promise.all(promises);
      results.push(...batchResults);
    } catch (error) {
      console.error(`Error processing batch:`, error);
      // Add failed transactions with default categorization
      batch.forEach(transaction => {
        results.push({
          ...transaction,
          generalCategory: "General",
          subCategory: "General → Miscellaneous",
          domainDescription: "Unable to categorize transaction due to processing error."
        });
      });
    }
  }
 console.log(results) 
  return results;
}

// ---- SINGLE TRANSACTION PROCESSING ----
async function processSingleTransaction(transaction) {
  try {
    // Create a minimal prompt with only essential transaction data
    const transactionData = {
      id: transaction.transaction_id,
      description: transaction.description,
      amount: transaction.amount,
      currency: transaction.currency,
      type: transaction.transaction_type,
      category: transaction.transaction_category
    };

    const userPrompt = `
Categorize this bank transaction with these fields:
- generalCategory (one of: Income, Shopping, Entertainment, Food & Dining, Transportation, Utilities, Health, Savings, Investments, Personal Care, Travel, Business, Education, Gifts & Donations, Miscellaneous)
- subCategory (a specific category under the general category)
- domainDescription (1-2 sentences about the transaction)

Return ONLY this JSON format:
{
  "transaction_id": "${transactionData.id}",
  "generalCategory": "Category",
  "subCategory": "Subcategory",
  "domainDescription": "Description"
}

Transaction:
${JSON.stringify(transactionData, null, 2)}
`;

    const resp = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { 
          role: "system", 
          content: "You are a financial transaction categorization expert. Respond with valid JSON only." 
        },
        { role: "user", content: userPrompt }
      ],
      response_format: { type: "json_object" },
      temperature: 0.1,
      max_tokens: 200 // Reduced for faster response
    });

    const text = resp.choices[0]?.message?.content || "";
    if (!text) throw new Error("Empty response from OpenAI");
    
    // Parse the JSON response
    const categorization = JSON.parse(text);
    
    // Merge the categorization with the original transaction
    return {
      ...transaction,
      generalCategory: categorization.generalCategory || "General",
      subCategory: categorization.subCategory || "General → Miscellaneous",
      domainDescription: categorization.domainDescription || "Transaction categorized."
    };
  } catch (error) {
    console.error(`Error processing transaction ${transaction.transaction_id}:`, error.message);
    // Return transaction with default categorization on error
    return {
      ...transaction,
      generalCategory: "General",
      subCategory: "General → Miscellaneous",
      domainDescription: "Unable to categorize transaction."
    };
  }
}

module.exports = { categorizeData };