const express = require('express');
const router = express();
const multer = require('multer');
const path = require('path');
const userController =  require("../controllers/userController");
const asyncMiddleware = require("../middlewares/async");

const cuisineStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'public/images'); // Destination folder for file storage
  },
  filename: (req, file, cb) => {
    // Extract the file extension, default to .png if not available
    let fileExtension = path.extname(file.originalname);
    if (!fileExtension) {
      fileExtension = '.png';
    }

    const customFileName = `Image-${Date.now()}${fileExtension}`;

    // Callback with the custom filename
    cb(null, customFileName);
  },
});

const ImageUploader = multer({
  storage: cuisineStorage,
});

// Add middleware to parse JSON bodies
router.use(express.json());

router.get("/categorizeData", asyncMiddleware(userController.categorizeData));


// router.post("/updateProfile",  ImageUploader.single("profileImage"),asyncMiddleware(userController.updateProfile));

// router.post("/saveResult",ImageUploader.single('file'), asyncMiddleware(adminController.saveResult));

module.exports = router;