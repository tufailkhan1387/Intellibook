require("dotenv").config();
const OpenAI = require("openai");

// Test if we can create an OpenAI client
try {
  const client = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY || "missing-key"
  });
  
  console.log("OpenAI client created successfully");
  console.log("API key present:", !!process.env.OPENAI_API_KEY);
  
  // Test a simple API call
  client.models.list().then(models => {
    console.log("Successfully connected to OpenAI API");
    console.log("Number of models available:", models.data.length);
  }).catch(error => {
    console.error("Error connecting to OpenAI API:", error.message);
  });
} catch (error) {
  console.error("Error creating OpenAI client:", error.message);
}